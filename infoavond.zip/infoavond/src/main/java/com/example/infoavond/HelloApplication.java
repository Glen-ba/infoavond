package com.example.infoavond;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;

public class HelloApplication extends Application {

    ArrayList<Ball> balls = new ArrayList<>();

    @Override
    public void start(Stage stage) {

        int width = 900;
        int height = 600;

        Group root = new Group();

        Rectangle background = new Rectangle(width, height);
        background.setFill(Color.valueOf(Settings.BACKGROUND_COLOR.toUpperCase()));

        root.getChildren().add(background);

        Scene scene = new Scene(root, width, height);

        for (int i = 0; i < Settings.BALL_COUNT; i++) {

            Ball ball = new Ball(
                    Math.random() * width,
                    Math.random() * height
            );

            balls.add(ball);
            root.getChildren().add(ball.getCircle());
        }

        scene.setOnMouseClicked(e -> {

            for(int i = 0; i < Settings.CLICK_SPAWN; i++){

                Ball ball = new Ball(e.getX(), e.getY());

                balls.add(ball);
                root.getChildren().add(ball.getCircle());

            }

        });

        scene.setOnKeyPressed(e -> {

            switch (e.getCode()) {

                case SPACE -> {

                    for (Ball ball : balls) {
                        ball.dx *= Settings.CHAOS_MULTIPLIER;
                        ball.dy *= Settings.CHAOS_MULTIPLIER;
                    }

                }

            }

        });

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {

                for (Ball ball : balls) {
                    ball.update(width, height);
                }

                for (int i = 0; i < balls.size(); i++) {
                    for (int j = i + 1; j < balls.size(); j++) {
                        balls.get(i).collide(balls.get(j));
                    }
                }

            }
        };

        timer.start();

        stage.setTitle("Bouncing Ball Simulator");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}