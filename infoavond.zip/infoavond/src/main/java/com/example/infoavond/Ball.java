package com.example.infoavond;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Ball {

    Circle circle;
    double dx;
    double dy;

    public Ball(double x, double y) {

        circle = new Circle(Settings.BALL_SIZE);

        circle.setTranslateX(x);
        circle.setTranslateY(y);

        if(Settings.RANDOM_COLORS){
            randomColor();
        }else{
            try{
                circle.setFill(Color.valueOf(Settings.BALL_COLOR.toUpperCase()));
            }catch(Exception e){
                circle.setFill(Color.WHITE);
            }
        }

        dx = (Math.random() - 0.5) * Settings.SPEED * 2;
        dy = (Math.random() - 0.5) * Settings.SPEED * 2;
    }

    public void update(double width, double height) {

        double x = circle.getTranslateX();
        double y = circle.getTranslateY();

        dy += Settings.GRAVITY;

        x += dx;
        y += dy;

        if (x <= Settings.BALL_SIZE || x >= width - Settings.BALL_SIZE) {
            dx *= -1;
            randomColor();
        }

        if (y <= Settings.BALL_SIZE || y >= height - Settings.BALL_SIZE) {
            dy *= -1;
            randomColor();
        }

        circle.setTranslateX(x);
        circle.setTranslateY(y);
    }

    public void collide(Ball other) {

        double dx = circle.getTranslateX() - other.circle.getTranslateX();
        double dy = circle.getTranslateY() - other.circle.getTranslateY();

        double distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < Settings.BALL_SIZE * 2) {

            double tempX = this.dx;
            double tempY = this.dy;

            this.dx = other.dx;
            this.dy = other.dy;

            other.dx = tempX;
            other.dy = tempY;

            randomColor();
            other.randomColor();
        }
    }

    public void randomColor() {

        if(Settings.RANDOM_COLORS){
            circle.setFill(Color.color(Math.random(), Math.random(), Math.random()));
        }

    }

    public Circle getCircle() {
        return circle;
    }
}