package com.example.infoavond;

public class Settings {

    // Hoeveel balletjes er standaard zijn
    public static int BALL_COUNT = 5;

    // Verander de grootte van de balletjes
    public static int BALL_SIZE = 20;

    // Verander de snelheid van de balletjes
    public static double SPEED = 3;

    // Random kleuren wanneer de ballen er zijn en botsen
    // Opties: true of false
    public static boolean RANDOM_COLORS = true;

    // Verander de kleur van de ballen
    // RANDOM_COLORS moet = false om dit te laten werken
    public static String BALL_COLOR = "blue";

    // Pas de zwaartekracht aan van de ballen
    // 0.0 zorgt ervoor dat er geen zwaartekracht is
    // Moet groter zijn dan 0.0
    public static double GRAVITY = 0.0;

    // Hoeveel ballen er komen wanneer je klikt
    public static int CLICK_SPAWN = 1;

    // Klik spatie een paar keer wanneer de ballen aan het bewegen zijn
    // Veranderd de grootte van het gevolg.
    // Moet groter zijn dan 0.1
    public static double CHAOS_MULTIPLIER = 1.5;

    // Pas de kleur aan van de achtergrond
    // De kleur moet in het engels
    // rood = red ; blauw = blue ; roos = pink ; zwart = black ; groen = green
    public static String BACKGROUND_COLOR = "blue";

}