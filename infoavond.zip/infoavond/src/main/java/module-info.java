module com.example.infoavond {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.infoavond to javafx.fxml;
    exports com.example.infoavond;
}